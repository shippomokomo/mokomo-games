-------------------------------------------------------------------
Moko Is You
ver 1.50a

				              製作者：Nono_Shijimi
                                                      ノノしじみ
						      2025/02/12
-------------------------------------------------------------------


------------------目次------------------
■１．挨拶
■２．レベルパック導入方法
■３．感想、不具合報告はこちら
■４．諸注意
■５．素材
■６. 更新履歴
----------------------------------------


■１．挨拶

　この度は「Moko Is You」をダウンロードしていただきありがとうございます。
　本レベルパックはBaba Is Youのノノしじみが作成した追加問題集になります。




■２．レベルパック導入方法

　本レベルパックを遊ぶ為にはPC版、およびSteam版を購入している必要があります。
　Switch版、アプリ版(Android,iOS)には対応しておりません。

　Steam版でのLevelPack導入方法
①「管理タブ」→「管理」→「ローカルファイルの閲覧」を選択し、
　　Baba Is Youのフォルダを開く

②「Data」フォルダ→「Worlds」フォルダを開く

③「Worlds」フォルダ内に「moko is you」のフォルダを移動させる。

④ゲームを起動して「ゲームスタート」を選択し、
　レベルパック選択欄に「Moko is You」が入っていれば成功です。




■３．感想、不具合報告はこちら
　●X(旧Twitter)
　製作者：ノノしじみ
　　@nono_shijimi


　※七宝もこも様は問題の作成に携わっておりません。
　　そちらへの本レベルパックについての問い合わせはご遠慮ください。



■４．諸注意
　●当ゲームを用いて発生した損害などの保証は一切できません。
　自己責任でお願いします。
　また、レベルパックの改造や内部データの抽出はご遠慮下さい。

　●本ゲームの攻略動画、実況動画などの投稿について
　　YouTube、Twitch、Twitter、お客様ご自身のウェブサイト、またはその他の動画共有サイトにて
　　良識の範囲内にて本レベルパックの攻略・紹介・実況・解説動画を投稿、配信をしていただくことが可能です。
　　（ただし、下記に記す禁止行為を伴う動画の投稿、配信は認めません。）
　　　また、動画投稿、配信に伴う製作者への問い合わせは不要です。

　●禁止事項
・違法、人種差別的、中傷、犯罪を助長する、またはその他の著しく不快な表現を含む動画、コンテンツの作成
・本レベルパックの内容を含む動画、コンテンツを製作者公式のコンテンツとして宣伝する行為




■５．素材
・BGM
　Sand Is Hot (Chepaki氏)
https://www.youtube.com/watch?v=IrdZEHlsp0c

　Baba Is Float (Chepaki氏)
https://www.youtube.com/watch?v=-bNS055B5hA

　Pixel Is Glow (DogeIsCut氏)
https://www.youtube.com/watch?v=ykV8WOtmnPA

・Sprite
　SAND (Marlowe氏)
　CARROT (Chryss the Crystalball氏)
BABA IS YOU Discordチャンネル:Asset Is Shareより

・ノノしじみ自作の素材
  MOKO 
  MOKOMO
  MOKOKO
  NAZUMI
  SUSHI
　SATELLITE
　レベルアイコン全て
　MAPの背景素材




■６. 更新履歴
2026/02/2	ver 1.50b
　総Level数：245
・以下のLevelの修正
  Pixel Dimensionエリア -6
　Space Stationエリア -11,-12

2026/02/1	ver 1.50a
　総Level数：245
・Warp RouteエリアのBGM音量を調整


・新規エリアを追加
　　Space Stationエリア(計15Level)


・以下のLevelの修正
    Voidエリア(Outerworld North-East) -7
    一部エリアのバグ修正



2026/01/29	ver 1.40a
　総Level数：230
・新規エリアを追加
　　Okunoshima Islandエリア(計12Level)
　　????????? エリア(計15Level)
　　???????? エリア(計8Level)

・既存エリアにLevelを追加
    Overworld                   に1Level追加
    Warp Routeエリア            に2Level追加
    Void(Outerworld North-East)  に1Level追加
    Pixel Dimensionエリア       に1Level追加


・以下のLevelの修正
    BABA New Townエリア -3
    Sea of Rapidsエリア -4
　　Stargazing Tourエリア -2
    Not Push Wastelandエリア -10
    Meta NetherworldNetherエリア -Ex6,-Ex7
    Voidエリア(Outerworld North-East) -8
    Warp Routeエリア -2,-5
    Another Dimensionエリア -Ex6
    Pixel Dimensionエリア -7,-9




2026/01/18	ver 1.30a
　総Level数：190

・看板の文章を日本語と英語の両方を表示させるように変更

・Outerworldエリア の背景を刷新

・既存エリアにLevelを追加
    NAZMEY LANDエリアに1Level追加
    〇〇〇〇に1Level追加

・新規エリアを追加
　　Pixel Dimensionエリア(計13Level)

・以下のLevelの修正
    NAZMEY LANDエリア -Ex1,Ex2,Ex3


    

2026/01/08	ver 1.20a
　総Level数：175

・ステージタイトルを英語に、サブタイトルを日本語に変更

・既存エリアにLevelを追加
    BABA New Townエリア        に2Level追加
    Abandoned Ruinsエリア      に2Level追加
    Philosophy Squareエリア    に2Level追加
    Sea of Rapidsエリア        に2Level追加
    Robot Factoryエリア        に2Level追加
    Strange Mineエリア         に2Level追加
    Not Push Wastelandエリア   に2Level追加
    Stargazing Tourエリア      に2Level追加
    Temple of Directionsエリア に2Level追加
    Solitary Peakエリア        に2Level追加



2025/05/24	ver 1.10b

・以下のLevelの修正
    Void(Outerworld North-East)エリア -2,-3
    Warp Routeエリア -2,-5
    Another Dimensionエリア -6


2025/05/18	ver 1.10a
　総Level数：155

・既存エリアにLevelを追加
    Overworldに1Level追加
　　Meta Netherworldエリアに2Level追加

・Overworldのマップ配置を変更
  ※レベルパック更新後の詰み対策のため、LEAFを追加しています。

・〇〇〇〇をクリア可能に変更

・新規エリアを追加
　　Outerworldエリア
    Warp Routeエリア(計8Level)
    Void(Outerworld North-East)エリア(計10Level)
    Another Dimensionエリア(計8Level)


　
・以下のLevelの修正
    Stargazing Tourエリア -3,-4,-7
    Temple of Directionsエリア -5,-6
    Solitary Peakエリア -2
    Meta NetherworldNetherエリア -2


2025/02/14	ver 1.00a
　総Level数：125

・初版







